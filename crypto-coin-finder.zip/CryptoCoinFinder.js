import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Line } from "react-chartjs-2";
import "chart.js/auto";

export default function CryptoCoinFinder() {
  const [coins, setCoins] = useState([]);
  const [filteredCoins, setFilteredCoins] = useState([]);
  const [maxMarketCap, setMaxMarketCap] = useState(50000000);
  const [minAgeDays, setMinAgeDays] = useState(30);

  useEffect(() => {
    fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_asc&per_page=100&page=1&sparkline=true"
    )
      .then((res) => res.json())
      .then((data) => {
        const filtered = data.filter((coin) => {
          const ageDays =
            (new Date() - new Date(coin.atl_date)) / (1000 * 60 * 60 * 24);
          return coin.market_cap < maxMarketCap && ageDays > minAgeDays;
        });
        setCoins(data);
        setFilteredCoins(filtered);
      });
  }, [maxMarketCap, minAgeDays]);

  return (
    <main className="p-4 space-y-4">
      <h1 className="text-3xl font-bold">🔍 Coin Finder (DEX Style)</h1>

      <div className="flex flex-col md:flex-row gap-4">
        <Input
          type="number"
          placeholder="Max Market Cap (USD)"
          value={maxMarketCap}
          onChange={(e) => setMaxMarketCap(Number(e.target.value))}
        />
        <Input
          type="number"
          placeholder="Min Age (Days)"
          value={minAgeDays}
          onChange={(e) => setMinAgeDays(Number(e.target.value))}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCoins.map((coin) => (
          <Card key={coin.id} className="rounded-2xl shadow-md">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">{coin.name}</h2>
                <img src={coin.image} alt={coin.name} className="w-8 h-8" />
              </div>
              <p className="text-sm text-muted">Market Cap: ${coin.market_cap.toLocaleString()}</p>
              <Line
                data={{
                  labels: coin.sparkline_in_7d.price.map((_, i) => i),
                  datasets: [
                    {
                      label: "7d Price",
                      data: coin.sparkline_in_7d.price,
                      borderColor: "#22c55e",
                      fill: false,
                    },
                  ],
                }}
                options={{
                  elements: {
                    point: { radius: 0 },
                  },
                  plugins: {
                    legend: { display: false },
                  },
                  scales: {
                    x: { display: false },
                    y: { display: false },
                  },
                }}
              />
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}